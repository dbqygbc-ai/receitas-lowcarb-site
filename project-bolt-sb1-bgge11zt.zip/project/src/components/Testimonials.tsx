import React, { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const Testimonials: React.FC = () => {
  const { ref, isVisible } = useScrollAnimation(0.2);
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      name: 'Maria Silva',
      role: 'Perdeu 15kg em 3 meses',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
      text: 'As receitas são incríveis! Nunca pensei que poderia emagrecer comendo tão gostoso. O plano de 4 semanas foi fundamental para manter o foco.',
      rating: 5
    },
    {
      name: 'João Santos',
      role: 'Perdeu 22kg em 6 meses',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
      text: 'Depois de tantas dietas malucas, finalmente encontrei algo sustentável. As receitas de doces low carb salvaram minha dieta!',
      rating: 5
    },
    {
      name: 'Ana Costa',
      role: 'Perdeu 18kg em 4 meses',
      image: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg',
      text: 'A lista de compras organizada facilita muito a vida. E o grupo no WhatsApp é um apoio incrível. Recomendo de olhos fechados!',
      rating: 5
    },
    {
      name: 'Carlos Lima',
      role: 'Perdeu 25kg em 8 meses',
      image: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg',
      text: 'Método científico que realmente funciona. Perdi peso sem passar fome e ainda descobri pratos novos que toda família adora.',
      rating: 5
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const nextTestimonial = () => {
    setCurrentIndex(currentIndex === testimonials.length - 1 ? 0 : currentIndex + 1);
  };

  const prevTestimonial = () => {
    setCurrentIndex(currentIndex === 0 ? testimonials.length - 1 : currentIndex - 1);
  };

  return (
    <section id="depoimentos" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-black mb-6">
            Histórias de transformação
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Conheça pessoas que transformaram suas vidas com nossas receitas low carb
          </p>
        </div>

        <div ref={ref} className={`relative max-w-4xl mx-auto transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          {/* Testimonial Card */}
          <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12 relative overflow-hidden">
            <div className="grid lg:grid-cols-3 gap-8 items-center">
              {/* Image */}
              <div className="lg:order-2 text-center">
                <div className="relative inline-block">
                  <img
                    src={testimonials[currentIndex].image}
                    alt={testimonials[currentIndex].name}
                    className="w-32 h-32 lg:w-40 lg:h-40 rounded-full object-cover mx-auto shadow-lg"
                  />
                  <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-black rounded-full flex items-center justify-center">
                    <div className="flex space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-3 w-3 text-white fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="lg:col-span-2 lg:order-1">
                <div className="mb-6">
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  
                  <blockquote className="text-xl lg:text-2xl text-gray-800 leading-relaxed mb-6 italic">
                    "{testimonials[currentIndex].text}"
                  </blockquote>
                  
                  <div>
                    <h4 className="text-xl font-bold text-black">
                      {testimonials[currentIndex].name}
                    </h4>
                    <p className="text-gray-600 font-medium">
                      {testimonials[currentIndex].role}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <div className="absolute top-1/2 -translate-y-1/2 left-4 right-4 flex justify-between pointer-events-none">
              <button
                onClick={prevTestimonial}
                className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors duration-200 pointer-events-auto"
              >
                <ChevronLeft className="h-6 w-6 text-gray-600" />
              </button>
              
              <button
                onClick={nextTestimonial}
                className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors duration-200 pointer-events-auto"
              >
                <ChevronRight className="h-6 w-6 text-gray-600" />
              </button>
            </div>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center space-x-3 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  index === currentIndex ? 'bg-black scale-125' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;