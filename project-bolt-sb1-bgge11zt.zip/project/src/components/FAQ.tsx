import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const FAQ: React.FC = () => {
  const { ref, isVisible } = useScrollAnimation(0.2);
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'As receitas são realmente saborosas?',
      answer: 'Sim! Todas as nossas receitas foram desenvolvidas por chefs especializados em culinária saudável e testadas por milhares de pessoas. Focamos em sabor e praticidade, garantindo que você não sinta que está fazendo sacrifícios.'
    },
    {
      question: 'Preciso de ingredientes caros ou difíceis de encontrar?',
      answer: 'Não! Todas as receitas usam ingredientes facilmente encontrados em qualquer supermercado. Priorizamos opções acessíveis e disponíveis, com alternativas para diferentes orçamentos.'
    },
    {
      question: 'Quanto tempo leva para preparar as receitas?',
      answer: 'A maioria das receitas leva entre 15 a 30 minutos para preparar. Temos opções para todos os momentos: receitas rápidas para o dia a dia e outras mais elaboradas para ocasiões especiais.'
    },
    {
      question: 'O plano funciona para vegetarianos?',
      answer: 'Sim! Incluímos uma seção completa com receitas vegetarianas e veganas low carb. Há opções para todos os tipos de alimentação e restrições dietéticas.'
    },
    {
      question: 'Como funciona o acesso ao material?',
      answer: 'Após a compra, você recebe instantaneamente o acesso por email. Todo o material fica disponível em uma área de membros exclusiva, que você pode acessar de qualquer dispositivo, a qualquer hora.'
    },
    {
      question: 'E se eu não gostar do produto?',
      answer: 'Oferecemos garantia incondicional de 7 dias. Se não ficar satisfeito por qualquer motivo, devolvemos 100% do seu dinheiro, sem perguntas ou burocracias.'
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-black mb-6">
            Perguntas frequentes
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tire todas as suas dúvidas sobre nossas receitas low carb
          </p>
        </div>

        <div ref={ref} className={`max-w-4xl mx-auto transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100"
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full px-6 lg:px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
                >
                  <h3 className="text-lg lg:text-xl font-semibold text-black pr-4">
                    {faq.question}
                  </h3>
                  {openIndex === index ? (
                    <ChevronUp className="h-6 w-6 text-gray-600 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="h-6 w-6 text-gray-600 flex-shrink-0" />
                  )}
                </button>
                
                <div className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                }`}>
                  <div className="px-6 lg:px-8 pb-6">
                    <p className="text-gray-600 leading-relaxed text-lg">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Call to Action */}
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-6">
              Ainda tem dúvidas? Entre em contato conosco!
            </p>
            <button className="px-8 py-4 bg-black text-white font-bold rounded-full hover:bg-gray-800 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
              Falar com Suporte
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;