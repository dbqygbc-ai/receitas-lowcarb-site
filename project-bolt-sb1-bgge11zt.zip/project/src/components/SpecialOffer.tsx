import React from 'react';
import { Check, Clock, Gift } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const SpecialOffer: React.FC = () => {
  const { ref, isVisible } = useScrollAnimation(0.3);

  const includes = [
    '150+ Receitas Low Carb Exclusivas',
    'Plano Nutricional de 4 Semanas',
    'Listas de Compras Organizadas', 
    'Receitas de Doces Low Carb',
    'Guia de Substituições',
    'Acesso Vitalício ao Conteúdo'
  ];

  const bonuses = [
    'Guia Completo Low Carb',
    'Calculadora de Macros',
    'Grupo VIP no WhatsApp'
  ];

  return (
    <section id="oferta" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-black text-white px-4 py-2 rounded-full text-sm font-semibold mb-6">
            <Clock className="h-4 w-4" />
            <span>Oferta por tempo limitado</span>
          </div>
          
          <h2 className="text-3xl lg:text-5xl font-bold text-black mb-6">
            Transforme sua alimentação hoje
          </h2>
        </div>

        <div ref={ref} className={`max-w-4xl mx-auto transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
        }`}>
          <div className="bg-gradient-to-br from-gray-50 to-white rounded-3xl shadow-2xl overflow-hidden border border-gray-100">
            <div className="grid lg:grid-cols-2 gap-0">
              {/* Image */}
              <div className="relative h-64 lg:h-auto">
                <img
                  src="https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg"
                  alt="Receitas Low Carb Premium"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>

              {/* Content */}
              <div className="p-8 lg:p-12">
                <div className="mb-8">
                  <h3 className="text-2xl lg:text-3xl font-bold text-black mb-4">
                    Receitas Low Carb Premium
                  </h3>
                  <p className="text-gray-600 text-lg leading-relaxed">
                    O método completo para emagrecer com prazer e saúde, 
                    baseado em ciência e testado por milhares de pessoas.
                  </p>
                </div>

                {/* What's Included */}
                <div className="mb-8">
                  <h4 className="text-xl font-bold text-black mb-4">O que você recebe:</h4>
                  <div className="space-y-3">
                    {includes.map((item, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                        <span className="text-gray-700">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bonuses */}
                {/* Pricing */}
                <div className="text-center border-t border-gray-200 pt-8">
                  <div className="mb-6">
                    <div className="text-sm text-gray-500 line-through">De R$ 69,99</div>
                    <div className="text-4xl font-bold text-black mb-2">
                      R$ 19,99
                    </div>
                    <div className="text-sm text-gray-600">
                      Pagamento único • Acesso vitalício
                    </div>
                  </div>

                  <button className="w-full px-8 py-4 bg-black text-white font-bold rounded-full hover:bg-gray-800 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl text-lg">
                    Quero Começar Agora
                  </button>

                  {/* Guarantee Section */}
                  <div className="mt-8 pt-6 border-t border-gray-100">
                    <div className="flex items-center justify-center space-x-3 mb-4">
                      <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center">
                        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                      </div>
                      <div className="text-left">
                        <h4 className="font-bold text-black">Garantia de 7 dias</h4>
                        <p className="text-sm text-gray-600">100% do seu dinheiro de volta</p>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-gray-500 mt-4">
                    Cancelamento fácil • Sem riscos
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SpecialOffer;