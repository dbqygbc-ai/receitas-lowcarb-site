import React from 'react';
import { ChefHat, Instagram, Facebook, Youtube, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  const quickLinks = [
    { label: 'Benefícios', href: '#beneficios' },
    { label: 'Receitas', href: '#oferta' },
    { label: 'Depoimentos', href: '#depoimentos' },
    { label: 'FAQ', href: '#faq' }
  ];

  const legalLinks = [
    { label: 'Política de Privacidade', href: '#' },
    { label: 'Termos de Uso', href: '#' },
    { label: 'Política de Reembolso', href: '#' }
  ];

  const socialLinks = [
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Youtube, href: '#', label: 'YouTube' },
    { icon: Mail, href: '#', label: 'Email' }
  ];

  return (
    <footer className="bg-black text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <ChefHat className="h-8 w-8 text-white" />
              <span className="text-2xl font-bold tracking-tight">
                Receitas Low Carb
              </span>
            </div>
            
            <p className="text-gray-300 text-lg leading-relaxed mb-6 max-w-md">
              Transforme sua alimentação com receitas científicas, saborosas e práticas. 
              Emagreça com prazer e viva com mais energia.
            </p>

            <div className="flex space-x-4">
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <a
                    key={index}
                    href={social.href}
                    className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors duration-200"
                    aria-label={social.label}
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xl font-bold mb-6">Links Rápidos</h4>
            <nav className="space-y-4">
              {quickLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  className="block text-gray-300 hover:text-white transition-colors duration-200"
                >
                  {link.label}
                </a>
              ))}
            </nav>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xl font-bold mb-6">Contato</h4>
            <div className="space-y-4 text-gray-300">
              <p>contato@receitaslowcarb.com</p>
              <p>Suporte: Segunda à Sexta<br />9h às 18h</p>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col lg:flex-row justify-between items-center space-y-4 lg:space-y-0">
            <div className="text-gray-400 text-sm">
              © 2025 Receitas Low Carb. Todos os direitos reservados.
            </div>
            
            <nav className="flex flex-wrap justify-center lg:justify-end space-x-6">
              {legalLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  className="text-gray-400 hover:text-gray-300 transition-colors duration-200 text-sm"
                >
                  {link.label}
                </a>
              ))}
            </nav>
          </div>

          <div className="text-center mt-8 pt-8 border-t border-gray-800">
            <p className="text-gray-500 text-sm max-w-2xl mx-auto">
              Este site não é afiliado ao Facebook ou qualquer entidade do Facebook. 
              Uma vez que você saia do Facebook, a responsabilidade não é deles e sim do nosso site. 
              Fazemos todos os esforços para indicar claramente e mostrar todas as provas do produto 
              e usar resultados reais.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;