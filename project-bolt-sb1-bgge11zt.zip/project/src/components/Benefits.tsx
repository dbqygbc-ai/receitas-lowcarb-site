import React from 'react';
import { BookOpen, Calendar, ShoppingCart, Cookie } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const Benefits: React.FC = () => {
  const { ref, isVisible } = useScrollAnimation(0.2);

  const benefits = [
    {
      icon: BookOpen,
      title: '150+ Receitas Exclusivas',
      description: 'Receitas testadas e aprovadas por nutricionistas, com instruções detalhadas passo a passo.'
    },
    {
      icon: Calendar,
      title: 'Plano de 4 Semanas Pronto',
      description: 'Cardápio completo organizado por semanas, eliminando a necessidade de planejamento.'
    },
    {
      icon: ShoppingCart,
      title: 'Lista de Compras Automática',
      description: 'Listas organizadas por categoria para facilitar suas compras no supermercado.'
    },
    {
      icon: Cookie,
      title: 'Doces Low Carb Inclusos',
      description: 'Sobremesas deliciosas sem culpa, para matar a vontade de doce sem sair da dieta.'
    }
  ];

  return (
    <section id="beneficios" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-black mb-6">
            Tudo que você precisa para ter sucesso
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Um sistema completo pensado para facilitar sua jornada low carb, 
            com tudo organizado e pronto para usar.
          </p>
        </div>

        <div ref={ref} className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className={`bg-white p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2 ${
                  isVisible 
                    ? 'opacity-100 translate-y-0' 
                    : 'opacity-0 translate-y-8'
                }`}
                style={{
                  transitionDelay: `${index * 150}ms`
                }}
              >
                <div className="w-16 h-16 bg-black rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="h-8 w-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-black mb-4">
                  {benefit.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Benefits;